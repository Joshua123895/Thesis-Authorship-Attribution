"""Langkah 5 — IndoBERT (JALANKAN TERAKHIR).

Fine-tune IndoBERT pada fold leave-one-topic-out yang SAMA PERSIS dengan
run_taskA.py, supaya perbandingannya adil.

Butuh GPU dan akses ke HuggingFace:
    pip install torch transformers

EKSPEKTASI REALISTIS: kemungkinan besar KALAH dari char n-gram.
150 dokumen latih untuk 50 kelas sangat sedikit untuk fine-tuning transformer.
Kalau memang kalah, itu MENJAWAB RQ3 (Tyo dkk. memprediksi n-gram unggul saat
kata-per-penulis rendah), bukan kegagalan. Laporkan apa adanya.

Catatan: median dokumen 200 kata (~260 token), jauh di bawah batas 512.
Tidak perlu windowing atau chunking sama sekali.

Output: results/tables/indobert_results.csv
"""
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder

import config as C
from corpus import load_docs
from splits import leave_one_topic_out

try:
    import torch
    from torch.utils.data import Dataset, DataLoader
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
except ImportError:
    raise SystemExit(
        "Butuh torch + transformers.\n"
        "  pip install torch transformers\n"
        "Jalankan di mesin ber-GPU (RTX 4060 cukup) atau di Google Colab."
    )


class EssayDataset(Dataset):
    def __init__(self, texts, labels, tokenizer):
        self.enc = tokenizer(list(texts), truncation=True, padding="max_length",
                             max_length=C.INDOBERT_MAXLEN, return_tensors="pt")
        self.labels = torch.tensor(labels, dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, i):
        item = {k: v[i] for k, v in self.enc.items()}
        item["labels"] = self.labels[i]
        return item


def train_one_fold(texts_tr, y_tr, texts_te, y_te, n_classes, device):
    tok = AutoTokenizer.from_pretrained(C.INDOBERT_MODEL)
    model = AutoModelForSequenceClassification.from_pretrained(
        C.INDOBERT_MODEL, num_labels=n_classes).to(device)

    dl_tr = DataLoader(EssayDataset(texts_tr, y_tr, tok),
                       batch_size=C.INDOBERT_BATCH, shuffle=True)
    dl_te = DataLoader(EssayDataset(texts_te, y_te, tok),
                       batch_size=C.INDOBERT_BATCH)

    opt = torch.optim.AdamW(model.parameters(), lr=C.INDOBERT_LR)
    model.train()
    for epoch in range(C.INDOBERT_EPOCHS):
        total = 0.0
        for batch in dl_tr:
            batch = {k: v.to(device) for k, v in batch.items()}
            opt.zero_grad()
            out = model(**batch)
            out.loss.backward()
            opt.step()
            total += out.loss.item()
        print(f"    epoch {epoch+1}/{C.INDOBERT_EPOCHS}  loss {total/len(dl_tr):.4f}")

    model.eval()
    preds = []
    with torch.no_grad():
        for batch in dl_te:
            batch = {k: v.to(device) for k, v in batch.items()}
            logits = model(**{k: v for k, v in batch.items() if k != "labels"}).logits
            preds += logits.argmax(-1).cpu().tolist()
    return np.array(preds)


def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cpu":
        print("PERINGATAN: tidak ada GPU. Ini akan sangat lambat.\n")
    print(f"device: {device}\n")

    texts, authors, topics, agg = load_docs()
    le = LabelEncoder()
    y = le.fit_transform(authors)
    n_classes = len(le.classes_)

    rows = []
    for train, test, tag in leave_one_topic_out(topics):
        print(f"  fold: held-out {tag}  (train {len(train)}, test {len(test)})")
        pred = train_one_fold(texts[train], y[train],
                              texts[test], y[test], n_classes, device)
        acc = accuracy_score(y[test], pred) * 100
        f1 = f1_score(y[test], pred, average="macro", zero_division=0) * 100
        rows.append({"fold": tag, "acc": acc, "macro_f1": f1})
        print(f"    -> acc {acc:.1f}  macroF1 {f1:.1f}\n")

    df = pd.DataFrame(rows)
    summary = pd.DataFrame([{
        "fold": "MEAN",
        "acc": df.acc.mean(), "acc_std": df.acc.std(),
        "macro_f1": df.macro_f1.mean(), "macro_f1_std": df.macro_f1.std(),
    }])
    out = pd.concat([df, summary], ignore_index=True)
    out.to_csv(C.TABLES / "indobert_results.csv", index=False)

    print(f"IndoBERT: acc {df.acc.mean():.1f} ±{df.acc.std():.1f}   "
          f"macroF1 {df.macro_f1.mean():.1f} ±{df.macro_f1.std():.1f}")
    print("Pembanding char n-gram: acc 24.0 ±5.5   macroF1 17.6 ±4.9")


if __name__ == "__main__":
    main()
